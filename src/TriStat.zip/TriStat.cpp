

#include "utilities.h"
#include "TriStat.h"
//Taken from SKSE64
typedef RE::TESForm* (*_LookupFormByID)(RE::FormID id);
REL::Relocation<_LookupFormByID> LookupFormByID(REL::ID(14461));
//
void TriStatTracker::startPlugin()
{
	if (started) {
		logger::info("plugin already started");
		return;
	}
	logger::info("Plugin started");
	SKSE::sendNotification("SkyLover37's TriStatTracker is now running.");
	started = true;
	return;
}



template <typename T>
void TriStatTracker::bufferUpdate(float mod)
{
	//RE::TESGlobal* Energy = slccStorage[0];
	//RE::TESGlobal* Efficiency = slccStorage[(int)T::EFFICIENCY];
	
	auto map = slccStorage[(int)T::BUFFER];
	for (std::map<std::string, RE::TESGlobal*>::iterator it = map.begin(); it != map.end(); ++it) {
		RE::TESGlobal* buffer = slccStorage[(int)T::BUFFER];
		if (!buffer) {
			logger::critical("BufferUpdate: returned a nullPtr from BUFFER storage from mod:" + it->first.c_str() + ", this is a severe error that affects the core of the mod.");
			continue;
		}
		float buff = buffer->value;
		buff += mod;
		it->second->value = buff;
		
	}
	
}

template <typename T>
void TriStatTracker::restored(float mod) 
{

		
		RE::TESGlobal* glob = slccStorage[(int)T::TOTAL_RESTORED]; 
		if (glob)
		{
			glob->value += mod;
			
		} else {
			logger::critical("Failed to retrieve a restored value from globals");
		}
		return;


}


template<typename T>
void TriStatTracker::damaged(float mod)
{
	mod = -1 * mod;
	RE::TESGlobal* totalDamage = slccStorage[(int)T::TOTAL_DAMAGED];
	RE::TESGlobal* highbuff = slccStorage[(int)T::HIGHEST_DAMAGE];
	RE::TESGlobal* recentbuff = slccStorage[(int)T::RECENT_HIGHEST_DAMAGE];
	if (!totalDamage && !highbuff && !recentbuff) {
		logger::critical("Failed to retrieve a global");
		return;
	}
		totalDamage->value += mod;
	if (mod > highbuff->value)
		highbuff->value = mod;

	if (mod > recentbuff->value)
		recentbuff->value = mod;
}


void TriStatTracker::DamageActorValue(RE::Actor* pCharacter, int AVModifiers, int actorVal, float mod, __int64 a5)
{
	_DamageActorVal(pCharacter, AVModifiers, actorVal, mod, a5);
	//logger::info(SL::String(AVModifiers));
	TriStatTracker* track = TriStatTracker::GetSingleton();
	if (!track->started)
		return;
	if (mod <= 0)
		return;

	if (&(*pCharacter) != &(**g_thePlayer)) {
		//logger::info("Not the player");
		return;
	}
	switch (actorVal) {
	case 24:
		if (mod > 0) {
			track->restored<TriStatTracker::health>(mod);
			track->bufferUpdate<TriStatTracker::health>(mod);
		} else
			track->damaged<TriStatTracker::health>(mod);
		//AVal = TriStatTracker::HEALTH_EFFICIENCY;
		break;
	case 25:
		if (mod > 0) {
			track->restored<TriStatTracker::magicka>(mod);
			track->bufferUpdate<TriStatTracker::magicka>(mod);
		} else
			track->damaged<TriStatTracker::magicka>(mod);
		//logger::info("AV: Magicka "+avV);
		//AVal = TriStatTracker::MAGICKA_EFFICIENCY;
		break;
	case 26:
		if (mod > 0) {
			track->restored<TriStatTracker::stamina>(mod);
			track->bufferUpdate<TriStatTracker::stamina>(mod);
		} else
			track->damaged<TriStatTracker::stamina>(mod);
		//logger::info("AV: Stamina ");
		//AVal = TriStatTracker::STAMINA_EFFICIENCY;
		break;
	default:
		//logger::info("Unhandled AV, ignoring");
		return;
		
	}

		
	return;
}


TriStatTracker::TriStatTracker()
{
	logger::info("Starting plugin");
	RE::ScriptEventSourceHolder::GetSingleton()->AddEventSink<RE::TESMagicEffectApplyEvent>(this);
	RE::ScriptEventSourceHolder::GetSingleton()->AddEventSink<RE::TESActiveEffectApplyRemoveEvent>(this);


	hdle = RE::TESDataHandler::GetSingleton();

	//Add TST to the OnAnimationEvent sink
	RE::PlayerCharacter** Player = g_thePlayer.get();
	RE::BSTSmartPointer<RE::BSAnimationGraphManager> grphmgr;
	(*Player)->GetAnimationGraphManager(grphmgr);
	logger::info(SL::String(grphmgr.get()->graphs.size()));
	RE::BSTSmartPointer<RE::BShkbAnimationGraph> graph = grphmgr.get()->graphs[0];
	graph->AddEventSink<RE::BSAnimationGraphEvent>(this);

	//Retrieve globals
	logger::info("Fetching globals");
	logger::info(SL::String(&(*skyrim_cast<RE::TESGlobal*>(hdle->LookupForm(0x022EA, "CalorieCounter.esp")))));
	
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//callories
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//healthefficiency
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>() );	//healthbuffer
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//highestHealthdamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//recenthighesthealthdamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//totalhealthdamaged
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());  //totalhealthrestored


	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//magickaefficiency
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//magickabuffer
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//highestmagickadamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//recenthighestmagickadamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//totalmagickadamaged
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//totalmagickarestored


	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//staminaefficiency
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//staminabuffer
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//higheststaminadamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//recenthigheststaminadamage
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//totalstaminadamaged
	slccStorage.push_back(std::map<std::string, RE::TESGlobal*>());	//totalstaminarestored


	logger::info(SL::String(slccStorage.size()));
	logger::info("Hooking RestoreAV");
	auto& trampoline = SKSE::GetTrampoline();
	//Hook Restore/DamageActorValue
	_DamageActorVal = trampoline.write_call<5>((REL::Module::get().base() + 0x0621104), DamageActorValue);
}
TriStatTracker::TriStatTracker(TriStatTracker&) {}
RE::BSEventNotifyControl TriStatTracker::ProcessEvent(const RE::TESMagicEffectApplyEvent* a_event, RE::BSTEventSource<RE::TESMagicEffectApplyEvent>* a_eventSource) 
{
	//SKSE::sendNotification("OnEffectStart");
	//logger::info("OnEffectStart");
	if (a_event && a_eventSource) {
		//RE::EffectSetting* mi2 = skyrim_cast<RE::EffectSetting*>(LookupFormByID(a_event->magicEffect));
	}
	//logger::info("Received event");
	return RE::BSEventNotifyControl::kContinue;
}
RE::BSEventNotifyControl TriStatTracker::ProcessEvent(const RE::BSAnimationGraphEvent* a_event, RE::BSTEventSource<RE::BSAnimationGraphEvent>* a_eventSource)
{
	static std::string lastStep = "";
	//RE::PlayerCharacter** Player = g_thePlayer.get();
	std::string curStep = a_event->tag.c_str();
	
	if (a_event && a_eventSource) 
	{
		logger::info(curStep.c_str());
		//The wiki says that tailMTIdle is only called when exiting stealth, but it is sent when you stop moving.
		if (curStep == "tailMTIdle") {
			lastStep = "";
		} else if (curStep == "FootLeft" || curStep == "FootRight") {

				if (lastStep == curStep)
					{
						logger::info("Full walk rotation");
						//(*Player)->RestoreActorValue(RE::ACTOR_VALUE_MODIFIER::kDamage, RE::ActorValue::kStamina, -1);
					}
					else if (lastStep == "")
							{
								lastStep = curStep;
							}
		} else if(curStep == "FootSprintRight" || curStep == "FootSptrintLeft") {

		}
		
	}
				
		//RE::EffectSetting* mi2 = skyrim_cast<RE::EffectSetting*>(LookupFormByID(a_event->magicEffect));
	//logger::info("Received event");
	return RE::BSEventNotifyControl::kContinue;
}


RE::BSEventNotifyControl TriStatTracker::ProcessEvent(const RE::TESActiveEffectApplyRemoveEvent* a_event, RE::BSTEventSource<RE::TESActiveEffectApplyRemoveEvent>* a_eventSource) {
	SKSE::sendNotification("OnEffectEnd");
	logger::info("OnEffectStart");
	if (a_event && a_eventSource) {}
	return RE::BSEventNotifyControl::kContinue;
}

void StartPlugin(RE::StaticFunctionTag*) {
	TriStatTracker::GetSingleton()->startPlugin();
	
}

bool AddStorageGlobal(RE::StaticFunctionTag*, int key, std::string mapKey, RE::TESGlobal* glob) {
	if (key >= 0 && key <= 19 && glob) {
		TriStatTracker::GetSingleton()->slccStorage[key][mapKey] = glob;
		return true;
	}
	return false;
	//TriStatTracker* tracker = TriStatTracker::GetSingleton();
	//tracker->slccModStorage[]
	
}

RE::TESGlobal* GetStorageGlobal(RE::StaticFunctionTag*, int key, std::string mapKey)
{
	if (key >= 0 && key <= 19) {
		TriStatTracker* track = TriStatTracker::GetSingleton();
		if (track->slccStorage[key].contains(mapKey)) {
			return track->slccStorage[key][mapKey];
		} else
			return NULL;
	}
}
bool RegisterFuncs(RE::BSScript::IVirtualMachine* a_vm)
{
	a_vm->RegisterFunction("startPlugin", "CalCo_SKSE", StartPlugin);
	a_vm->RegisterFunction("GetStorageGlobal", "CalCo_SKSE", GetStorageGlobal);
	a_vm->RegisterFunction("AddStorageGlobal", "CalCo_SKSE", AddStorageGlobal);
	return true;
}

//typedef void(__fastcall* DamageActorValue)(RE::Actor* pCharacter, int AVModifiers, RE::ActorValue actorVal, float mod, std::uintptr_t a5);




