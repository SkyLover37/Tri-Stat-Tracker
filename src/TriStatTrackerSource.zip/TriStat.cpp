
#pragma once
#include "utilities.h"
#include "TriStat.h"
#include <fstream>
#include <iostream>
	//Taken from SKSE64
//typedef RE::TESForm* (*_LookupFormByID)(RE::FormID id);
//REL::Relocation<_LookupFormByID> LookupFormByID(REL::ID(14461));
//




std::vector<std::string> storageKey{ "HEALTH_BUFFER", "HEALTH_HIGHEST_DAMAGE", "HEALTH_RECENT_HIGHEST_DAMAGE", "HEALTH_TOTAL_DAMAGED", "HEALTH_TOTAL_RESTORED",
		"MAGICKA_BUFFER", "MAGICKA_HIGHEST_DAMAGE", "MAGICKA_RECENT_HIGHEST_DAMAGE", "MAGICKA_TOTAL_DAMAGED", "MAGICKA_TOTAL_RESTORED",
		"STAMINA_BUFFER", "STAMINA_HIGHEST_DAMAGE", "STAMINA_RECENT_HIGHEST_DAMAGE", "STAMINA_TOTAL_DAMAGED", "STAMINA_TOTAL_RESTORED" };
	template <typename T>
void TriStatTracker::bufferUpdate(float mod)
{
	std::map<std::string, std::map<std::string, RE::TESGlobal*>>::iterator it;
	//logger::info("Updating buffer");
	for (it = slccStorage.begin(); it != slccStorage.end(); it++) {
		RE::TESGlobal* globalVal = it->second[storageKey[(int)T::BUFFER]];
		logger::info("Buffer Update: " + SL::String(globalVal->value));
		if (globalVal) {
			globalVal->value += mod;
		} else {
			logger::critical("BufferUpdate: returned a nullPtr from globalvar storage, this is a severe error that affects the core of the mod.");
		}
	}
}
template <typename T>
void TriStatTracker::restored(float mod) 
{

		std::map<std::string, std::map<std::string, RE::TESGlobal*>>::iterator it;

	for (it = slccStorage.begin(); it != slccStorage.end(); it++) {
			RE::TESGlobal* glob = it->second[storageKey[(int)T::TOTAL_RESTORED]];
			if (glob) {
				glob->value += mod;

			} else {
				logger::critical("Failed to retrieve a restored value from globals, from mod: "+it->first);
			}
		}
}


template<typename T>
void TriStatTracker::damaged(float mod)
{
	mod = -1 * mod;
	std::map<std::string, std::map<std::string, RE::TESGlobal*>>::iterator it;

	for (it = slccStorage.begin(); it != slccStorage.end(); it++) {
		RE::TESGlobal* totalDamage = it->second[storageKey[(int)T::TOTAL_DAMAGED]];
		RE::TESGlobal* highbuff = it->second[storageKey[(int)T::HIGHEST_DAMAGE]];
		RE::TESGlobal* recentbuff = it->second[storageKey[(int)T::RECENT_HIGHEST_DAMAGE]];
		if (!totalDamage && !highbuff && !recentbuff) {
			logger::critical("Failed to retrieve a global from mod: "+it->first);
			continue;
		}

		totalDamage->value += mod;
		if (mod > highbuff->value)
			highbuff->value = mod;

		if (mod > recentbuff->value)
			recentbuff->value = mod;
	}
}
void UpdateTxt() {
	
	//std::string line;
	//std::ofstream TriStore("Data/SKSE/Plugins/TriStatTrackerData/TriStatTracker.txt");
	
	//if (TriStore.is_open()) {
	//	TriStore << "Health: " << (*g_thePlayer)->GetActorValue(RE::ActorValue::kHealth) << "\n";
	//	TriStore << "Magicka: " << (*g_thePlayer)->GetActorValue(RE::ActorValue::kMagicka) << "\n";
	//	TriStore << "Stamina: " << (*g_thePlayer)->GetActorValue(RE::ActorValue::kStamina) << "\n";
		
	//}
	//TriStore.close();
}

void TriStatTracker::DamageActorValue(RE::Actor* pCharacter, int AVModifiers, int actorVal, float mod, __int64 a5)
{
	_DamageActorVal(pCharacter, AVModifiers, actorVal, mod, a5);
	

	
	//logger::info(SL::String(AVModifiers));
	TriStatTracker* track = TriStatTracker::GetSingleton();
	
	if (&(*pCharacter) != &(**g_thePlayer)) {
		//logger::info("Not the player");
		return;
	}
	switch (actorVal) {
	case 24:
		//UpdateTxt();
		if (!track->state)
			return;
		if (mod > 0) {
			track->restored<TriStatTracker::health>(mod);
			track->bufferUpdate<TriStatTracker::health>(mod);
		} else
			track->damaged<TriStatTracker::health>(mod);
		//AVal = TriStatTracker::HEALTH_EFFICIENCY;
		break;
	case 25:
		//UpdateTxt();
		if (!track->state)
			return;
		if (mod > 0) {
			track->restored<TriStatTracker::magicka>(mod);
			track->bufferUpdate<TriStatTracker::magicka>(mod);
		} else
			track->damaged<TriStatTracker::magicka>(mod);
		//logger::info("AV: Magicka "+avV);
		//AVal = TriStatTracker::MAGICKA_EFFICIENCY;
		break;
	case 26:
		//UpdateTxt();
		if (!track->state)
			return;
		if (mod > 0) {
			track->restored<TriStatTracker::stamina>(mod);
			track->bufferUpdate<TriStatTracker::stamina>(mod);
		} else
			track->damaged<TriStatTracker::stamina>(mod);
		//logger::info("AV: Stamina ");
		//AVal = TriStatTracker::STAMINA_EFFICIENCY;
		break;
	default:
		//logger::info("Unhandled AV, ignoring");
		return;
		
	}
	//Write the 3 updated stats to txt file.
	
		
	return;
}


TriStatTracker::TriStatTracker()
{
	logger::info("Starting plugin");
	if (varsLoaded) {
		logger::info("Vars are loaded but constructor was called anyway...?");
		return;
	}
	//RE::ScriptEventSourceHolder::GetSingleton()->AddEventSink<RE::TESMagicEffectApplyEvent>(this);
	//RE::ScriptEventSourceHolder::GetSingleton()->AddEventSink<RE::TESActiveEffectApplyRemoveEvent>(this);


	hdle = RE::TESDataHandler::GetSingleton();

	//logger::info(SL::String(slccStorage.size()));
	logger::info("Hooking RestoreAV");
	auto& trampoline = SKSE::GetTrampoline();
	//Hook Restore/DamageActorValue
	_DamageActorVal = trampoline.write_call<5>((REL::Module::get().base() + 0x0621104), DamageActorValue);
	UpdateTxt();
	varsLoaded = true;
}
TriStatTracker::TriStatTracker(TriStatTracker&) {}
RE::BSEventNotifyControl TriStatTracker::ProcessEvent(const RE::TESMagicEffectApplyEvent* a_event, RE::BSTEventSource<RE::TESMagicEffectApplyEvent>* a_eventSource) 
{
	//SKSE::sendNotification("OnEffectStart");
	//logger::info("OnEffectStart");
	if (a_event && a_eventSource) {
		//RE::EffectSetting* mi2 = skyrim_cast<RE::EffectSetting*>(LookupFormByID(a_event->magicEffect));
	}
	//logger::info("Received event");
	return RE::BSEventNotifyControl::kContinue;
}


RE::BSEventNotifyControl TriStatTracker::ProcessEvent(const RE::TESActiveEffectApplyRemoveEvent* a_event, RE::BSTEventSource<RE::TESActiveEffectApplyRemoveEvent>* a_eventSource) {
	SKSE::sendNotification("OnEffectEnd");
	logger::info("OnEffectStart");
	if (a_event && a_eventSource) {}
	return RE::BSEventNotifyControl::kContinue;
}

bool StartPlugin(RE::StaticFunctionTag*) {
	//SKSE::ModCallbackEvent tests;
	//RE::BSTEventSource<SKSE::ModCallbackEvent>* ModEvn = (RE::BSTEventSource<SKSE::ModCallbackEvent>*)SKSE::GetMessagingInterface()->GetEventDispatcher(SKSE::MessagingInterface::Dispatcher::kModEvent);
	//tests.eventName = "SKSEModEventTest";
	//tests.numArg = 0.0f;
	//tests.strArg = "";
	//tests.sender = NULL;
	//ModEvn->SendEvent(&tests);
	TriStatTracker* track = TriStatTracker::GetSingleton();
	if (!((track->slccStorage.size()) > 0))
		return false; 
	track->state = true;
	return true;
	
	
}
void StopPlugin(RE::StaticFunctionTag*) {
	
	TriStatTracker::GetSingleton()->state = false;
}

bool GetState(RE::StaticFunctionTag*) {
	return TriStatTracker::GetSingleton()->state;
}
bool AddStorageSingleGlobal(RE::StaticFunctionTag*, RE::TESGlobal* toAdd, int location, std::string mapKey) 
{
	if (!toAdd) {
		return false;
	}
	TriStatTracker* track = TriStatTracker::GetSingleton();
	track->slccStorage[mapKey][storageKey[location]] = toAdd;
	return true;
}
void RemoveStorageSingleGlobal(RE::StaticFunctionTag*, int location, std::string mapKey)
{
	TriStatTracker* track = TriStatTracker::GetSingleton();
	track->slccStorage[mapKey].erase(track->slccStorage[mapKey].find(storageKey[location]));

}
bool AddStorageGlobals(RE::StaticFunctionTag*, RE::BGSListForm* globalVals, std::string mapKey)
{
	
	
	if (globalVals->forms.size() == 15) {
		
		TriStatTracker* track = TriStatTracker::GetSingleton();
		for (uint32_t i = 0; i < globalVals->forms.size(); i++) {
			logger::info(SL::String(i));
			if (!globalVals->forms[i]) {
				return false;
			}
			track->slccStorage[mapKey][storageKey[i]] = skyrim_cast<RE::TESGlobal*>(globalVals->forms[i]);
				
			
				
		}
		return true;
			
	} else {
		return false;
	}
}
void RemoveStorageGlobals(RE::StaticFunctionTag*, std::string mapKey) {
	
	TriStatTracker* track = TriStatTracker::GetSingleton();
	track->slccStorage.erase(mapKey);
}
bool RegisterFuncs(RE::BSScript::IVirtualMachine* a_vm)
{
	a_vm->RegisterFunction("StartTracker", "TST_SKSE", StartPlugin);
	a_vm->RegisterFunction("StopTracker", "TST_SKSE", StopPlugin);
	a_vm->RegisterFunction("GetTrackerState", "TST_SKSE", GetState);
	a_vm->RegisterFunction("AddSingleGlobal", "TST_SKSE", AddStorageSingleGlobal);
	a_vm->RegisterFunction("AddStorageGlobals", "TST_SKSE", AddStorageGlobals);
	a_vm->RegisterFunction("RemoveStorageGlobals", "TST_SKSE", RemoveStorageGlobals);
	a_vm->RegisterFunction("RemoveSingleGlobal", "TST_SKSE", RemoveStorageSingleGlobal);
	return true;
}

//typedef void(__fastcall* DamageActorValue)(RE::Actor* pCharacter, int AVModifiers, RE::ActorValue actorVal, float mod, std::uintptr_t a5);




