#pragma once
#include <vector>
#include <map>
#include <PCH.h>




//void loadConsumables();

//The Player
extern REL::Relocation<RE::PlayerCharacter**> g_thePlayer;
class TriStatTracker : public RE::BSTEventSink<RE::TESMagicEffectApplyEvent>, public RE::BSTEventSink<RE::TESActiveEffectApplyRemoveEvent>
{
public:
	
	
	static TriStatTracker* GetSingleton()
	{
		static TriStatTracker* instance;
		if (!instance) {
			instance = new TriStatTracker;
			
	
		}
		return instance;
	}
	

	enum struct health
	{
		//EFFICIENCY = 3,				
		BUFFER = 0,					
		HIGHEST_DAMAGE,		
		RECENT_HIGHEST_DAMAGE,	
		TOTAL_DAMAGED,			
		TOTAL_RESTORED,			
	};
	enum struct magicka
	{
		//EFFICIENCY = 9,		
		BUFFER = 5,					
		HIGHEST_DAMAGE,			
		RECENT_HIGHEST_DAMAGE,	
		TOTAL_DAMAGED,			
		TOTAL_RESTORED			
	};
	enum struct stamina
	{
		//EFFICIENCY = 15,				
		BUFFER = 10,					
		HIGHEST_DAMAGE,			
		RECENT_HIGHEST_DAMAGE,	
		TOTAL_DAMAGED,			
		TOTAL_RESTORED			
	};
	RE::TESDataHandler* hdle;
	
	std::map<std::string, std::map<std::string, RE::TESGlobal*>> slccStorage;
	
	//RE::TESGlobal* Energy;
	//std::vector<RE::TESGlobal*> Efficiency;
	//std::vector<RE::TESGlobal*> efficiencyMod;
	
	std::vector<RE::SpellItem*> spl;
	
	bool varsLoaded = false;
	bool state = false;
	


	//void load(SKSE::SerializationInterface* a_intfc);
	
	//void save(SKSE::SerializationInterface* a_intfc);
	
	template <typename T>
	void bufferUpdate(float mod);

	template <typename T>
	void restored(float mod);

	template <typename T>
	void damaged(float mod);

	static void DamageActorValue(RE::Actor* pCharacter, int AVModifiers, int actorVal, float mod, __int64 a5);

	
	inline static REL::Relocation<decltype(DamageActorValue)> _DamageActorVal;

protected:
	RE::BSEventNotifyControl ProcessEvent(const RE::TESMagicEffectApplyEvent* a_event, RE::BSTEventSource<RE::TESMagicEffectApplyEvent>* a_eventSource) override;
	//RE::BSEventNotifyControl ProcessEvent(const RE::BSAnimationGraphEvent* a_event, RE::BSTEventSource<RE::BSAnimationGraphEvent>* a_eventSource) override;
	RE::BSEventNotifyControl ProcessEvent(const RE::TESActiveEffectApplyRemoveEvent* a_event, RE::BSTEventSource<RE::TESActiveEffectApplyRemoveEvent>* a_eventSource) override;

private:
	TriStatTracker();
	TriStatTracker(TriStatTracker&);
	~TriStatTracker() {}
};
	void load(SKSE::SerializationInterface* a_intfc);
	void save(SKSE::SerializationInterface* a_intfc);
bool RegisterFuncs(RE::BSScript::IVirtualMachine* a_vm);

